<?php

include '../../conexaoPHP/conexao.php';

// get the post records
$cpf = $_POST['cpf'];
$nome = $_POST['nome'];
$email = $_POST['email'];
$telefone = $_POST['telefone'];
$nascimento = $_POST['nascimento'];
$admissao = $_POST['admissao'];
$funcao = $_POST['funcao'];
$senha = $_POST['senha'];


$sql = "INSERT INTO `tb_colaborador` (`TB_Gestor_idTB_Gestor`, `Colaborador_Nome`, `Colaborador_CPF`, `Colaborador_Email`, `Colaborador_Nascimento`, `Colaborador_Telefone`, `Colaborador_Adimissao`, `Colaborador_Senha`, `Colaborador_Status`, `Colaborador_Foto`, `Colaborador_Funcao`) VALUES ('1', '$nome', '$cpf', '$email', '$nascimento', '$telefone', '$admissao', '$senha', '1', 'das', '$funcao')";

if (mysqli_query($conn, $sql)) {
      echo "New record created successfully";
  

} else {
      echo "Error: " . $sql . "<br>" . mysqli_error($conn);

}

mysqli_close($conn);

?>