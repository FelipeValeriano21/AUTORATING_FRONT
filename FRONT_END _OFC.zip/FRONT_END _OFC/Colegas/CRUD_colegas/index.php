<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Departamento - AUTORATING</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css">    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
    <link rel="stylesheet" href="../side.css">
    <link rel="stylesheet" href="../../assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="../../assets/fonts/fontawesome-all.min.css">
     <link rel="shortcut icon" type="imagex/png" href="../../Login/img/AUTORATING.png">
     <link rel="stylesheet" href="assets/css/styles.min.css">
</head>
<body id="body-pd">
    <header class="header" id="header">
        <div style="color: white;" class="header_toggle "> <i class='bx bx-expand-horizontal' id="header-toggle"></i> </div>
        <h3></h3>
        <a href="#" id="btn-sair" class="nav_link"> <i class='bx bx-log-out nav_icon'></i> <span class="nav_name">Sair</span> </a> 
   
    </header>
    <main>
    <div class="l-navbar" id="nav-bar"> 
        <nav class="nav">
            <div> <a href="#" class="nav_logo"> <i class='bx bx-layer nav_logo-icon' ></i> <span class="nav_logo-name">Autorating</span> </a>
               <div  class="img m-3"> 
                <img class="img-fluid rounded-circle" alt="avatar1" src="https://mdbcdn.b-cdn.net/img/new/avatars/9.webp"  id="fotomenu" />
               
              </div>
               <hr>
                <div class="nav_list mt-4">
                     <a href="" class="nav_link"> <i class='bx bx-grid-alt nav_icon'></i> <span class="nav_name">Menu</span> </a> 
                     <a href="#" class="nav_link active" > <i class='bx bx-group nav_icon'></i> <span class="nav_name">Meu departamento</span> </a> 
                     <a href="#" class="nav_link"> <i class='bx bx-check nav_icon'></i> <span class="nav_name">Realizadas</span> </a> 
                     <a href="#" class="nav_link"> <i class='bx bx-bar-chart-alt-2 nav_icon'></i> <span class="nav_name">Dashboard</span> </a> 
                     <a href="../profile/index.html" class="nav_link"> <i class='bx bx-user nav_icon'></i> <span class="nav_name">Dados Pessoais</span> </a>
                    </div>
            </div> 
        </nav>
    </div>
    <main>

        

      
            <div class="container profile profile-view" id="profile">
                <div class="row">
                    <div class="col-md-12 alert-col relative">
                        <div class="alert alert-info absolue center" role="alert"><button class="btn-close" type="button" aria-label="Close" data-bs-dismiss="alert"></button><span>Profile save with success</span></div>
                    </div>
                </div>
                <form action="insert_colaborador.php" method="post">
                    <div class="row profile-row">
                        <div class="col-md-4 relative">
                            <div class="avatar">
                                <div class="avatar-bg center"></div>
                            </div><input class="form-control form-control" type="file" name="avatar-file">
                        </div>
                        <div class="col-md-8">
                            <h1 style="font-size: 23px;">Novo colaborador</h1>
                            <hr>
                            <div class="row">
                                <div class="col-sm-12 col-md-6">
                                    <div class="form-group mb-3"><label class="form-label">CPF</label><input class="form-control" type="text" name="cpf" id="cpf"></div>
                                </div>
                                <div class="col-sm-12 col-md-6">
                                    <div class="form-group mb-3"><label class="form-label">Nome</label><input class="form-control" type="text" name="nome" id="nome"></div>
                                </div>
                            </div>
                            <div class="form-group mb-3"><label class="form-label">Email</label><input class="form-control" type="email" autocomplete="off" required=""name="email" id="email"></div>
                            <div class="row">
                                <div class="col-sm-12 col-md-6">
                                    <div class="form-group mb-3"><label class="form-label">Data de Nascimento</label><input class="form-control" type="date" name="nascimento" id="nascimento"autocomplete="off" required=""></div>
                                </div>
                                <div class="col-sm-12 col-md-6">
                                    <div class="form-group mb-3"><label class="form-label">Telefone</label><input class="form-control" type="text" autocomplete="off" name="telefone" id="telefone" required=""></div>
                                </div>
                            </div>
                            <div class="row">
                            
                                <div class="col-sm-12 col-md-6">
                                    <div class="form-group mb-3"><label class="form-label">Função</label><input class="form-control" type="text" autocomplete="off" name="funcao" id="funcao"  required=""></div>
                                </div>
                                <div class="col-sm-12 col-md-6">
                                    <div class="form-group mb-3"><label class="form-label">Data de Adimissão</label><input class="form-control" type="date"  autocomplete="off" required=""  name="admissao" id="admissao" ></div>
                                </div>
                            </div>
                            <div class="form-group mb-3"><label class="form-label">Senha</label><input class="form-control" type="password" autocomplete="off" required=""name="senha" id="senha"></div>
                            <hr>
                            <div class="row">
                                <div class="col-md-12 content-right"><input class="btn btn-success form-btn" type="submit"><button class="btn btn-danger form-btn" type="reset" style="background: rgb(230,28,47);">Voltar</button></div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
      
      

    </main>

  <!--

 <footer>   
      <div class="text-center p-4" style=" background-color: rgb(8, 87, 156); color: white;">
      © 2023 Copyright: TECHNOTRIBE MLV
      </div>
  </footer>


  -->
  
 
</body>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script src="assets/js/script.min.js"></script>
<script src="../assets/bootstrap/js/bootstrap.min.js"></script>
<script src="../assets/js/script.min.js"></script>
<script src="../assets/js/chart.min.min.js"></script>       
<script src="../main.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
</html>
