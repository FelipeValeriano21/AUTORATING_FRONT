<?php

session_start();
// Inclua o arquivo de conexão
require_once("conexao.php");

// Verifica se o formulário de login foi submetido
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtenha os valores do formulário
    $cpf = $_POST["cpf"];
    $password = $_POST["password"];

    // Consulta SQL para verificar as credenciais do usuário
    $sql = "SELECT * FROM TB_Gestor WHERE Gestor_CPF = '$cpf' AND GESTOR_Senha = '$password'";
    $result = $conn->query($sql);

    // Verifica se a consulta foi bem-sucedida e se encontrou um registro correspondente
    if ($result->num_rows == 1) {
        // O usuário foi autenticado com sucesso
       header("location: ../Profile/index.php");
        // Você pode redirecionar o usuário para outra página aqui, se desejar
    } else {
        // As credenciais estão incorretas
        $_SESSION['status'] = "";
        header("location: ../Login/login.php");
    }
}
?>